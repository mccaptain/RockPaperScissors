package com.mcgrath.rockpaperscissors.main;


import java.util.ArrayList;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.view.Menu;
import android.view.MenuItem;

import com.example.rockpaperscissors.R;
import com.mcgrath.rockpaperscissors.database.UserDatabaseHelper;
import com.mcgrath.rockpaperscissors.events.LoadUserEvent;
import com.mcgrath.rockpaperscissors.events.PlayAgainEvent;
import com.mcgrath.rockpaperscissors.events.SaveUserInfoEvent;
import com.mcgrath.rockpaperscissors.events.UserPlayEvent;

import de.greenrobot.event.EventBus;

public class CentralActivity extends FragmentActivity
{
	private User mUser;
	private Character mUsersMoveCode;
	public UserDatabaseHelper mDBHelper;
	
	private enum Pages
	{
		USER_INPUT,
		GAME,
		RESULT
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_central);
		if (savedInstanceState == null)
		{
			switchFrag( getFrag( Pages.USER_INPUT ) );
		}
		else
		{
			mUser = savedInstanceState.getParcelable("user");
		}

		mDBHelper = new UserDatabaseHelper( this );
        EventBus.getDefault().register( this );
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.central, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	private void switchFrag( Fragment aFragment )
	{
		getSupportFragmentManager().beginTransaction()
			.replace( R.id.container, aFragment )
			.commit();
	}
	
	private Fragment getFrag( Pages aPage )
	{
		switch( aPage )
		{
		case USER_INPUT:
			Fragment theUInputFrag = (Fragment)UserInputFragment.newInstance(null);
			return theUInputFrag;
		case GAME:
			Bundle theBundle = new Bundle();
			theBundle.putParcelable("user", mUser);
			Fragment theGameFrag = (Fragment)GameFragment.newInstance( theBundle );
			return theGameFrag;
		case RESULT:
			Bundle theBundlee = new Bundle();
			theBundlee.putParcelable("user", mUser);
			theBundlee.putChar("move", mUsersMoveCode );
			Fragment theResultFrag = (Fragment)ResultFragment.newInstance( theBundlee );
			return theResultFrag;
		}
		return null;
	}
	
	@Override
	public void onSaveInstanceState(Bundle outState) {
		outState.putParcelable("user", mUser);
		if( mUsersMoveCode != null )
		outState.putChar("move", mUsersMoveCode );
		super.onSaveInstanceState(outState);
	}
	
	public void onEvent( SaveUserInfoEvent aEvent )
	{
		mUser = aEvent.getUser();
		mDBHelper.saveUser( mDBHelper.getWritableDatabase(), mUser );
		switchFrag( getFrag( Pages.GAME ) );
	}
	
	public void onEvent( LoadUserEvent aEvent )
	{
		mUser = mDBHelper.getUserWithName( mDBHelper.getReadableDatabase(), aEvent.getUserID() );
		switchFrag( getFrag( Pages.GAME ) );
	}
	
	public void onEvent( UserPlayEvent aEvent )
	{
		//record user stats
		mUsersMoveCode = aEvent.getMove();
		switchFrag( getFrag( Pages.RESULT ) );
	}
	
	public void onEvent( PlayAgainEvent aEvent )
	{
		switchFrag( getFrag( Pages.GAME ) );
		if( mUser != null )
		{
			mDBHelper.updateUserWins( mDBHelper.getWritableDatabase(), mUser );
		}
	}

	@Override
	protected void onDestroy()
	{
		mDBHelper.close();
		super.onDestroy();
	}
	
}
