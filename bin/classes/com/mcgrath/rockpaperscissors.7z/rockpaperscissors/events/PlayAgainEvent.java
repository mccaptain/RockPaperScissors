package com.mcgrath.rockpaperscissors.events;

public class PlayAgainEvent
{
	public PlayAgainEvent(  )
	{
	}
}